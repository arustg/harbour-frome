# Frome v.0.1
- a simple app for calculating percentage from number
